*PADS-LIBRARY-SCH-DECALS-V9*
PIN 0 0 100 10 100 10 2 1 0 0 0 1
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 94 6 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 94 6 0 0 0 0 "Regular default"
REF-DES
OPEN 2 10 0 -1
0 0
200 0
0603WAF470JT5E 0 0 100 10 100 10 2 1 0 2 0 0
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 9 1 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 14 10 0 0 0 0 "Regular ����"
REF-DES
CLOSED 8 10 0 -1
-100 40
100 40
100 40
100 -40
100 -40
-100 -40
-100 -40
-100 40
T200 0 0 2 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
T-200 0 0 0 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
0805CG200J500NT 0 0 100 10 100 10 2 4 0 2 0 0
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 9 1 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 14 10 0 0 0 0 "Regular ����"
REF-DES
OPEN 2 10 0 -1
-20 -80
-20 80
OPEN 2 10 0 -1
100 0
20 0
OPEN 2 10 0 -1
20 80
20 -80
OPEN 2 10 0 -1
-20 0
-100 0
T-200 0 0 0 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
T200 0 0 2 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
PIN 0 0 100 10 100 10 2 1 0 0 0 0
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 9 1 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 14 10 0 0 0 0 "Regular ����"
REF-DES
OPEN 2 10 0 -1
0 0
100 0
PIN_1 0 0 100 10 100 10 2 1 0 0 0 0
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 9 1 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 14 10 0 0 0 0 "Regular ����"
REF-DES
OPEN 2 10 0 -1
0 0
50 0
Res 0 0 100 10 100 10 2 1 0 2 0 0
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 9 1 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 14 10 0 0 0 0 "Regular ����"
REF-DES
CLOSED 8 10 0 -1
-100 40
100 40
100 40
100 -40
100 -40
-100 -40
-100 -40
-100 40
T200 0 0 2 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
T-200 0 0 0 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
Short-Symbol 0 0 100 10 100 10 2 1 0 2 0 0
TIMESTAMP 2025.12.17.18.56.50
"Default Font"
"Default Font"
0 0 0 0 9 1 0 0 0 0 "Regular default"
PART-TYPE
0 0 0 0 14 10 0 0 0 0 "Regular ����"
REF-DES
CLOSED 8 10 0 -1
-50 0
0 30
0 30
50 0
50 0
0 -30
0 -30
-50 0
T100 0 0 2 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
T-100 0 0 0 100 10 0 4 210 -30 0 0 PIN
P-100 0 0 1 0 0 0 0 128
